# LLING-TCC

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mobile-first.css" media="screen">
    <title>lling</title>
</head>
<body>
    <div class="grid">
        <header class="header">
            <div class="header__logo">Logo</div>
            <section class="header__pesquisar">
                <input type="text" placeholder="Pesquise um serviço de foto">
            </section>
            <nav class="header__navegacao">
                <div class="navegacao__item">Casaento</div>
                <div class="navegacao__item">Criança</div>
                <div class="navegacao__item">Bebes</div>
                <div class="navegacao__item">Cosplay</div>
                <div class="navegacao__item">Formatura</div>
            </nav>
        </header>
        <main class="main">
            
        </main>
    </div>
</body>
</html>
@charset "UTF-8";

* {
    padding: 0;
    margin: 0;
}

:root {

}

.gris {
    
}


